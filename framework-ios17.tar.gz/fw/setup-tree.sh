#!/usr/bin/env bash
# Rebuild the author's UniXNU tree on top of the public base commit:
#   framework commits -> framework diff -> per-submodule commits/diffs at the BASES revisions.
# Runs inside the UniXNU checkout. Usage: setup-tree.sh <framework-bundle-dir> [repo-root]
set -uo pipefail
FW="${1:?framework bundle dir}"
ROOT="${2:-$PWD}"
cd "$ROOT" || exit 1
git config user.email ci@localhost >/dev/null 2>&1
git config user.name ci >/dev/null 2>&1
git config commit.gpgsign false >/dev/null 2>&1

echo "== base: $(git rev-parse HEAD)"

echo "== framework commits"
for p in "$FW"/commits/UniXNU/*.patch; do
  [ -e "$p" ] || continue
  if git am -3 --keep-cr "$p" >/dev/null 2>&1; then
    echo "am ok   $(basename "$p")"
  else
    git am --abort >/dev/null 2>&1 || true
    if git apply --3way "$p" >/dev/null 2>&1; then
      git add -A >/dev/null 2>&1; git commit -qm "$(basename "$p" .patch)" >/dev/null 2>&1
      echo "apply ok $(basename "$p")"
    else
      echo "FAILED  $(basename "$p")"
    fi
  fi
done

if [ -f "$FW/diffs/UniXNU.diff" ]; then
  if git apply --3way "$FW/diffs/UniXNU.diff" >/dev/null 2>&1; then
    git add -A >/dev/null 2>&1; git commit -qm "framework diff" >/dev/null 2>&1
    echo "diff ok"
  else
    echo "diff FAILED"
  fi
fi

[ -f "$FW/BASES.txt" ] || { echo "no BASES.txt"; exit 0; }

echo "== submodules at BASES"
while read -r name sha url; do
  case "$name" in UniXNU|device|''|'#'*) continue;; esac
  path=$(printf '%s' "$name" | sed -e 's#^drivers_#drivers/#' -e 's#^kits_#kits/#')
  if [ ! -d "$path/.git" ]; then
    rm -rf "$path"
    git clone -q "$url" "$path" 2>/dev/null || { echo "clone failed $url"; continue; }
  fi
  if ! git -C "$path" checkout -q "$sha" 2>/dev/null; then
    echo "checkout failed $name $sha"
    continue
  fi
  if [ -d "$FW/commits/$name" ]; then
    for p in "$FW"/commits/"$name"/*.patch; do
      [ -e "$p" ] || continue
      if git -C "$path" am -3 --keep-cr "$p" >/dev/null 2>&1; then
        echo "  am ok   $name/$(basename "$p")"
      else
        git -C "$path" am --abort >/dev/null 2>&1 || true
        if git -C "$path" apply --3way "$p" >/dev/null 2>&1; then
          git -C "$path" add -A >/dev/null 2>&1
          git -C "$path" commit -qm "$(basename "$p" .patch)" >/dev/null 2>&1
          echo "  apply ok $name/$(basename "$p")"
        else
          echo "  FAILED  $name/$(basename "$p")"
        fi
      fi
    done
  fi
  if [ -f "$FW/diffs/$name.diff" ]; then
    if git -C "$path" apply --3way "$FW/diffs/$name.diff" >/dev/null 2>&1; then
      git -C "$path" add -A >/dev/null 2>&1
      git -C "$path" commit -qm "$name diff" >/dev/null 2>&1
      echo "  diff ok $name"
    else
      echo "  diff FAILED $name"
    fi
  fi
done < "$FW/BASES.txt"

rm -f .gitmodules
echo "== setup-tree done"
