#!/usr/bin/env python3
"""VerifiedRoot inputs for the iOS 17 (arm64e fileset) owner root: header-only policies.

The kernel carries, per window, the signed 160-byte header, its 384-byte RSA-3072 signature and the 395-byte
trusted key anchor (544 + 395 bytes) and never the block hash table: the tables of both windows live in userdata
as the version 2 data objects "<window>.hashes". NativeUfs reads them back and vr_open authenticates the whole
envelope, because the signed header carries the table digest and the key digest.

Inputs: <bundle>/{os,systemos}/ each holding the files the owner key produced:
    header.bin (160)   signature.bin (384)   trusted-key.bin (395)
    hashes.bin (32 bytes per 4096-byte block)   -- or just the digest in table.sha256 when the table is not shipped
These are public material; the private key that signed the headers never enters this repository.
Output: build/verified-root-os-xnu-bundle/libVerifiedRootProbe.a (CONFIG_XNU_VERIFIED_ROOT_ARCHIVE).
"""
import hashlib
import json
import os
import struct
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from kernel_target import TRIPLE, check_object


def policy_dir():
    candidates = []
    if os.environ.get('VERIFIED_ROOT_DIR'):
        candidates.append(Path(os.environ['VERIFIED_ROOT_DIR']))
    # device/ios17/verified-root is the shipped location; the overlay copy resolves one level deeper.
    for base in (ROOT, ROOT.parent, ROOT.parent.parent):
        candidates.append(base / 'ios17' / 'verified-root')
        candidates.append(base / 'verified-root')
    for candidate in candidates:
        if (candidate / 'os').is_dir() and (candidate / 'systemos').is_dir():
            return candidate
    raise SystemExit('no verified-root policy bundle; expected ios17/verified-root/{os,systemos}')


POLICIES = policy_dir()
out = ROOT / 'build/verified-root-os-xnu-bundle'
out.mkdir(parents=True, exist_ok=True)

records, key = [], None
for name in ('os', 'systemos'):
    policy = POLICIES / name
    header, signature = (policy / 'header.bin').read_bytes(), (policy / 'signature.bin').read_bytes()
    if len(header) != 160 or len(signature) != 384:
        raise SystemExit(f'{policy}: expected a 160-byte header and a 384-byte signature')
    image_bytes, block_count = struct.unpack_from('<Q', header, 24)[0], struct.unpack_from('<Q', header, 32)[0]
    this_key = (policy / 'trusted-key.bin').read_bytes()
    if len(this_key) != 395:
        raise SystemExit(f'{policy}: expected a 395-byte trusted key anchor')
    if hashlib.sha256(this_key).digest() != header[120:152]:
        raise SystemExit(f'{policy}: the signed header does not carry this trusted key')
    table_digest = header[88:120]
    table_bytes = block_count * 32
    if (policy / 'hashes.bin').is_file():
        hashes = (policy / 'hashes.bin').read_bytes()
        if hashlib.sha256(hashes).digest() != table_digest:
            raise SystemExit(f'{policy}: the signed header does not carry this hash table')
        table_bytes = len(hashes)
    elif (policy / 'table.sha256').is_file():
        if bytes.fromhex((policy / 'table.sha256').read_text().strip()) != table_digest:
            raise SystemExit(f'{policy}: the signed header does not carry this hash table digest')
    if block_count != table_bytes // 32:
        raise SystemExit(f'{policy}: {block_count} blocks do not match a {table_bytes}-byte table')
    if key is not None and this_key != key:
        raise SystemExit('Both policies must be signed under the same trusted key')
    key = this_key
    head = out / f'{name}-header-only.bin'
    head.write_bytes(header + signature)
    (out / 'trusted-key.bin').write_bytes(key)
    records.append(dict(name=name, header_only=str(head), image_bytes=image_bytes, block_count=block_count,
                        table_bytes=table_bytes, table_sha256=table_digest.hex(),
                        header_sha256=hashlib.sha256(header + signature).hexdigest(),
                        trusted_key_sha256=hashlib.sha256(this_key).hexdigest()))

# The crypto self-test only runs with the offline-owner-root-check boot-arg. It needs the sample symbols, but with
# header-only policies it stops at its first vr_open, so the samples stay four blocks of zeroes it never compares.
indices = [0, 1, records[0]['block_count'] // 2, records[0]['block_count'] - 1]
lengths = [4096, 4096, 4096, 4096]
samples = out / 'original-samples.bin'
samples.write_bytes(b'\0' * (4096 * len(indices)))

os_head, sys_head = records[0]['header_only'], records[1]['header_only']
assembly = out / 'inputs.S'
assembly.write_text(f'''// Generated header-only VerifiedRoot inputs (iOS 17 21H16, owner key of this repository). The hash tables
// are userdata data objects, so only the signed headers and the trusted key anchor are linked in.
.section __DATA_CONST,__const
.balign 8
.globl _verified_root_manifest, _verified_root_manifest_bytes
_verified_root_manifest:
.incbin "{os_head}"
_verified_root_manifest_bytes:
.quad . - _verified_root_manifest
.globl _verified_root_key
_verified_root_key:
.incbin "{out / 'trusted-key.bin'}"
.balign 8
.globl _verified_root_sample_indices
_verified_root_sample_indices:
.quad {','.join(map(str, indices))}
.globl _verified_root_sample_lengths
_verified_root_sample_lengths:
.quad {','.join(map(str, lengths))}
.globl _verified_root_samples
_verified_root_samples:
.incbin "{samples}"
.balign 8
.globl _verified_root_systemos_manifest
_verified_root_systemos_manifest:
.incbin "{sys_head}"
.balign 8
.globl _verified_root_policies, _verified_root_policy_count
_verified_root_policies:
.quad _verified_root_manifest, 544
.quad _verified_root_systemos_manifest, 544
_verified_root_policy_count:
.quad 2
''')

# The bsd_init compile record names this include directory (build-fuxi-verified-root-policy.py makes it too).
(ROOT / 'build/xnu/ios-obj/EXPORT_HDRS/libsa').mkdir(parents=True, exist_ok=True)
recipe = ROOT / 'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/bsd_init.o.json'
record = json.loads(recipe.read_text().strip().rstrip(','))
objects = []
for source in (ROOT / 'kits/VerifiedRoot/src/verified_root.c', ROOT / 'kits/VerifiedRoot/adapters/xnu_crypto.c',
               ROOT / 'scripts/qemu-entry/verified-root-probe.c'):
    destination = out / (source.stem + '.o')
    arguments, command, index = record['arguments'], [], 0
    while index < len(arguments):
        value = arguments[index]
        if value == record['file']:
            command.append(str(source))
        elif value == '-o':
            command += ['-o', str(destination)]
            index += 1
        elif value in ('-MF', '-MJ'):
            index += 1
        elif value not in ('-MD', '-MP'):
            command.append(value)
        index += 1
    command += ['-I' + str(ROOT / 'kits/VerifiedRoot/include'), '-Werror']
    result = subprocess.run(command, cwd=record['directory'], capture_output=True, text=True)
    (out / (source.stem + '.log')).write_text(result.stdout + result.stderr)
    if result.returncode:
        raise SystemExit(result.stderr[-3500:])
    objects.append(destination)
subprocess.run(['xcrun', 'clang', '-target', TRIPLE, '-c', str(assembly), '-o', str(out / 'inputs.o')], check=True)
objects.append(out / 'inputs.o')
for obj in objects:
    check_object(obj.read_bytes(), obj.name)
archive = out / 'libVerifiedRootProbe.a'
archive.unlink(missing_ok=True)
subprocess.run(['xcrun', 'ar', 'rcs', str(archive), *map(str, objects)], check=True)
(out / 'inputs.json').write_text(json.dumps(dict(policies=records, trusted_key_sha256=hashlib.sha256(key).hexdigest(),
    sample_indices=indices, sample_lengths=lengths, header_only=True, policy_dir=str(POLICIES),
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()), indent=2) + '\n')
print(f'{archive}: header-only VerifiedRoot inputs for {len(records)} policies from {POLICIES}')
